ALTER TABLE "AccountDeletionRequest" ADD COLUMN "verificationCodeHash" TEXT;
ALTER TABLE "AccountDeletionRequest" ADD COLUMN "verificationExpiresAt" TIMESTAMP(3);
ALTER TABLE "AccountDeletionRequest" ADD COLUMN "verifiedAt" TIMESTAMP(3);
CREATE UNIQUE INDEX "AccountDeletionRequest_verificationCodeHash_key" ON "AccountDeletionRequest"("verificationCodeHash");
CREATE INDEX "AccountDeletionRequest_email_createdAt_idx" ON "AccountDeletionRequest"("email","createdAt");
