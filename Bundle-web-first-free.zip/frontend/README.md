# Bundle universal client

Expo Router / React Native client for Bundle.

## Web-first launch

Web onboarding removes the phone/SMS stage:

`email -> profile -> photos -> identity -> photo verification -> profile review -> membership stage`

Native iOS/Android remains:

`email -> phone -> SMS code -> profile -> photos -> identity -> photo verification -> profile review -> membership -> dating`

The web build uses browser local storage for session persistence; native uses SecureStore.

Production web export:

```bash
npx expo export --platform web
```

The generated site is in `dist/`.
